-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 13, 2017 at 05:34 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `customer_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(255) NOT NULL,
  `c_email` varchar(255) NOT NULL,
  `c_address` text NOT NULL,
  `c_zip` varchar(6) NOT NULL,
  `c_telephone` varchar(10) NOT NULL,
  `c_dob` date NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`c_id`, `c_name`, `c_email`, `c_address`, `c_zip`, `c_telephone`, `c_dob`) VALUES
(1, 'Kunal', 'kunalshinde90@yahoo.com', 'Pune', '422101', '8983113095', '1990-07-21'),
(2, 'Rahul ', 'rahul@yahoo.com', 'Nasik', '422101', '2345678675', '1995-04-03'),
(3, 'Kunal', 'kunalshinde901@yahoo.com', 'Pune', '422101', '8983113095', '1990-07-21'),
(4, 'Kunal', 'kunalshinde902@yahoo.com', 'Pune', '422101', '8983113095', '1990-07-21'),
(5, 'Kunal', 'kunalshinde903@yahoo.com', 'Pune', '422101', '8983113095', '1990-07-21'),
(6, 'Rahul ', 'rahul232@yahoo.com', 'Nasik', '422101', '2345678675', '1995-05-18'),
(7, 'Kunal', 'kunal23423@yahoo.com', 'Pune', '422101', '8983113095', '1990-07-21');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
