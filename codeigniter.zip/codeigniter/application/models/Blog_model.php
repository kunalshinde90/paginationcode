<?php
class Blog_model extends CI_Model
{
		public function search($name,$email,$age,$limit, $start)
        {

        	//echo "sdfg";die();
        	$this->db->limit($limit, $start);
        	$array = array();
        	if($name != '')
        		$array['c_name'] = $name;
        	if($email != '')
        		$array['c_email'] = $email;
        	if($age != '')
			
		   //$array['c_age'] = $age;

                $this->db->select('*');
		        $this->db->from('customer');
		        $this->db->where($array);
			if($age==1)
			{
			$this->db->where("DATEDIFF(CURDATE(), `c_dob`)/365<25");
			}
			else if($age==1)
			{
			$this->db->where("DATEDIFF(CURDATE(), `c_dob`)/365>=25");
			}
		        $query = $this->db->get();
		        return $result = $query->result();
        }

        public function record_count($name,$email,$age) {
		
		//echo $name.$email.$age;
		if($name != '')
        		$array['c_name'] = $name;
        	if($email != '')
        		$array['c_email'] = $email;
        	if($age != '')
        		//$array['c_age'] = $age;
		if($array){
		$this->db->where($array);
		}
		
		if($age==1)
		{
			$this->db->where("DATEDIFF(CURDATE(), `c_dob`)/365<25");
		}
		else if($age==2)
		{
			$this->db->where("DATEDIFF(CURDATE(), `c_dob`)/365>=25");
		}		
		$num_rows = $this->db->count_all_results('customer');
		return $num_rows;
    	}
}
