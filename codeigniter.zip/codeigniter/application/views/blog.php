<html>
<head>
          <title>My Blog</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  
</head>
<body>
<div>
<form action="<?php base_url();?>" method="post">
  <div class>
	  <div>Name : <input type="text" value="<?php if(isset($name)) { echo $name; } else { echo ''; } ?>" name="name"/></div>
	  <div>Email: <input type="text" value="<?php if(isset($email)) { echo $email; } else { echo ''; } ?>" name="email"/>  </div>
	  <!--<div>Age : <input type="text" value="<?php if(isset($age)) { echo $age; } else { echo ''; } ?>" name="age"/></div>-->
	<div>Age : <select name="age" id="age">
		<option value="" <?php if($age==0) { echo 'SELECTED'; } else { echo ''; } ?>>Select Age</option>
		<option value="1" <?php if($age==1) { echo 'SELECTED'; } else { echo ''; } ?>>Less than 25 years</option>
		<option value="2" <?php if($age==2) { echo 'SELECTED'; } else { echo ''; } ?>>Greater than or equal to 25 years</option>		
		</select>
	</div>	
  </div>
   
<input type="submit" name="submit" value="Submit"/>
</form> 
  <table class="table">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
    <?php 
	if($data)
	{	
	foreach ($data as $key => $value) {
    	?>
      <tr>
        <td><?php echo $value->c_name; ?></td>
        <td><?php echo $value->c_address; ?></td>
        <td><?php echo $value->c_email; ?></td>
      </tr>
    <?php }
	}else {
      ?>
	<tr>
        <td colspan="3">Record Not Found</td>
        
      </tr>
    <?php } ?>		
    </tbody>
  </table>
  <p><?php echo $links; ?></p>
</div>

	
</body>
</html>
