<?php
class Blog extends CI_Controller {

        public function index()
        {
		$name = '';
		$address = '';
		$age = '';
		if($this->input->post())
		{
                        $name = $this->input->post('name');
                        $email = $this->input->post('email');
                        $age = $this->input->post('age');
                        $this->session->set_userdata('name', $name);
                        $this->session->set_userdata('email', $email);
                        $this->session->set_userdata('age', $age);
			
		}
                elseif ($this->session->userdata('name') || $this->session->userdata('email') || $this->session->userdata('age'))
                {
                        $name = $this->session->userdata('name');
                        $email = $this->session->userdata('email');
                        $age = $this->session->userdata('age');
			
                        
                }
                $this->load->model('blog_model');

                $config = array();
                $config["base_url"] = base_url()."index.php/blog/index";
                $config["total_rows"] = $this->blog_model->record_count($name,$email,$age);
                $config["per_page"] = 2;
                $config["uri_segment"] = 3;
		//echo $config["total_rows"];
                $this->pagination->initialize($config);

                $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                $data['data'] = $this->blog_model->search($name,$email,$age,$config["per_page"], $page);
                $data["links"] = $this->pagination->create_links();
		$data['name']=$name;
		$data['email']=$email;
		$data['age']=$age;
                $this->load->view('blog',$data);
        }

        
}
